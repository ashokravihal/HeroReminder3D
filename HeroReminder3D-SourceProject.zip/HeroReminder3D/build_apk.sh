#!/bin/bash
# ╔══════════════════════════════════════════════════════════════╗
# ║        HERO REMINDER 3D — APK BUILD SCRIPT                  ║
# ╚══════════════════════════════════════════════════════════════╝
set -e

echo ""
echo "⚡ ═══════════════════════════════════════════"
echo "⚡  HERO REMINDER 3D — BUILD SCRIPT"
echo "⚡ ═══════════════════════════════════════════"
echo ""

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# ── Step 1: Check Java ─────────────────────────────────────────
if ! command -v java &>/dev/null; then
  echo "❌ Java not found. Install JDK 17: https://adoptium.net"
  exit 1
fi
echo "✅ Java: $(java -version 2>&1 | head -1)"

# ── Step 2: Generate keystore if missing ───────────────────────
if [ ! -f "app/hero_keystore.jks" ]; then
  echo "🔑 Generating signing keystore..."
  keytool -genkeypair -v \
    -keystore app/hero_keystore.jks \
    -alias hero_key \
    -keyalg RSA -keysize 2048 \
    -validity 10000 \
    -storepass HeroReminder2024 \
    -keypass HeroReminder2024 \
    -dname "CN=Hero Reminder, OU=App, O=HeroApps, L=City, S=State, C=US"
  echo "✅ Keystore generated!"
fi

# ── Step 3: Make gradlew executable ───────────────────────────
chmod +x gradlew 2>/dev/null || true

# ── Step 4: Build debug APK ────────────────────────────────────
echo ""
echo "🔨 Building DEBUG APK (faster, no signing required)..."
./gradlew assembleDebug --no-daemon

DEBUG_APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$DEBUG_APK" ]; then
  echo ""
  echo "✅ DEBUG APK READY!"
  echo "📦 Location: $DEBUG_APK"
  echo "📏 Size: $(du -sh "$DEBUG_APK" | cut -f1)"
  cp "$DEBUG_APK" "HeroReminder3D-debug.apk"
  echo "📱 Copied to: HeroReminder3D-debug.apk"
fi

# ── Step 5: Build release APK (signed) ────────────────────────
echo ""
echo "🔨 Building RELEASE APK (signed, optimized)..."
./gradlew assembleRelease --no-daemon

RELEASE_APK="app/build/outputs/apk/release/app-release.apk"
if [ -f "$RELEASE_APK" ]; then
  echo ""
  echo "✅ RELEASE APK READY!"
  echo "📦 Location: $RELEASE_APK"
  echo "📏 Size: $(du -sh "$RELEASE_APK" | cut -f1)"
  cp "$RELEASE_APK" "HeroReminder3D-release.apk"
  echo "📱 Copied to: HeroReminder3D-release.apk"
fi

echo ""
echo "⚡ ═══════════════════════════════════════════"
echo "⚡  BUILD COMPLETE! Install on your device:"
echo "⚡  adb install HeroReminder3D-debug.apk"
echo "⚡ ═══════════════════════════════════════════"
