# ⚡ Hero Reminder 3D
### A Marvel-Inspired 3D Glassmorphic Reminder App for Android

---

## 📦 How to Build the APK (3 Methods)

### Method 1: Android Studio (EASIEST — Recommended)
1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio → `File → Open` → Select this folder
3. Wait for Gradle sync (~2-3 minutes first time)
4. Click **▶ Run** (green play button) to install on device/emulator, OR
5. Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
6. APK saved to: `app/build/outputs/apk/debug/app-debug.apk`

### Method 2: Command Line (macOS/Linux)
```bash
cd HeroReminder3D
chmod +x gradlew
chmod +x build_apk.sh
./build_apk.sh
```

### Method 3: Command Line (Windows)
```cmd
cd HeroReminder3D
gradlew.bat assembleDebug
```
APK will be at: `app\build\outputs\apk\debug\app-debug.apk`

---

## 🚀 Install on Android Device
```bash
# Enable USB Debugging on your Android phone first, then:
adb install HeroReminder3D-debug.apk

# Or directly copy APK to phone and open it
# (Enable "Install from Unknown Sources" in Settings → Security)
```

---

## 🦸 App Features

| Feature | Description |
|---------|-------------|
| 🎨 **3D Glassmorphic UI** | Floating cards with depth, neon glow, parallax |
| 🌌 **Animated Background** | 60 moving particles + nebula orbs + grid |
| ⚡ **Priority Levels** | Normal 🔵, Heroic 🔥, Legendary ⚡ |
| 🔔 **Local Notifications** | Works fully offline with exact alarms |
| 💥 **Full Screen Alerts** | Comic explosion animation + hero voice messages |
| 🔄 **Repeat Missions** | Daily, Weekly, Monthly scheduling |
| 🎵 **Sound Selection** | Hero Alarm / Funny Voice / Dramatic Mission |
| 💾 **Room Database** | All data saved locally, persists after reboot |
| 🗑️ **Swipe to Delete** | Left-swipe with explosion animation |
| ✅ **Mission Complete** | Confetti celebration screen |

---

## 📁 Project Structure

```
HeroReminder3D/
├── app/src/main/
│   ├── java/com/hero/reminder/
│   │   ├── MainActivity.kt              ← App entry point
│   │   ├── data/
│   │   │   ├── model/Reminder.kt        ← Data model + enums
│   │   │   ├── db/ReminderDatabase.kt   ← Room database
│   │   │   ├── db/ReminderDao.kt        ← Database queries
│   │   │   └── repository/             ← Data repository
│   │   ├── viewmodel/
│   │   │   └── ReminderViewModel.kt    ← Business logic
│   │   ├── notifications/
│   │   │   ├── AlarmScheduler.kt       ← Exact alarm scheduling
│   │   │   ├── AlarmReceiver.kt        ← Alarm broadcast receiver
│   │   │   └── ReminderService.kt      ← Foreground notification service
│   │   └── ui/
│   │       ├── theme/Theme.kt          ← Colors, typography
│   │       ├── components/
│   │       │   ├── HeroComponents.kt   ← Particles, glass card, FAB
│   │       │   ├── ReminderCard.kt     ← 3D mission card + swipe
│   │       │   └── AddReminderDialog.kt ← Add/edit modal
│   │       └── screens/
│   │           ├── HomeScreen.kt       ← Main screen
│   │           └── AlertActivity.kt   ← Full-screen alarm screen
│   ├── AndroidManifest.xml
│   └── res/
│       ├── drawable/                   ← Vector icons
│       └── values/                     ← Strings, themes
└── build_apk.sh                        ← One-click build script
```

---

## 🛠 Tech Stack

- **Language**: Kotlin
- **UI**: Jetpack Compose + Material 3
- **Database**: Room (SQLite)  
- **Animations**: Compose Animation API (60fps)
- **Alarms**: AlarmManager with exact scheduling
- **Architecture**: MVVM + Repository pattern
- **Min SDK**: 24 (Android 7.0+)
- **Target SDK**: 34 (Android 14)

---

## ⚙️ Requirements to Build

- JDK 17+ 
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Gradle 8.2 (auto-downloaded)
- Internet connection on first build (to download dependencies)

---

*Built with ❤️ for heroes everywhere* ⚡
