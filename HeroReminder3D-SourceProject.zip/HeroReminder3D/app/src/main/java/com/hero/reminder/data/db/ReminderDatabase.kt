package com.hero.reminder.data.db

import android.content.Context
import androidx.room.*
import com.hero.reminder.data.model.*

@TypeConverters(Converters::class)
@Database(entities = [Reminder::class], version = 1, exportSchema = false)
abstract class ReminderDatabase : RoomDatabase() {
    abstract fun reminderDao(): ReminderDao

    companion object {
        @Volatile private var INSTANCE: ReminderDatabase? = null
        fun getDatabase(context: Context): ReminderDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, ReminderDatabase::class.java, "hero_reminder_db")
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}

class Converters {
    @TypeConverter fun fromPriority(p: Priority) = p.name
    @TypeConverter fun toPriority(s: String) = Priority.valueOf(s)
    @TypeConverter fun fromRepeat(r: RepeatType) = r.name
    @TypeConverter fun toRepeat(s: String) = RepeatType.valueOf(s)
    @TypeConverter fun fromSound(s: HeroSound) = s.name
    @TypeConverter fun toSound(s: String) = HeroSound.valueOf(s)
}
