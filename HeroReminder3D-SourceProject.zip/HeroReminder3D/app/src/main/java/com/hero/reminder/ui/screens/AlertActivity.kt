package com.hero.reminder.ui.screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hero.reminder.data.model.Priority
import com.hero.reminder.ui.theme.*

class AlertActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val reminderId = intent.getIntExtra("reminder_id", -1)
        val title = intent.getStringExtra("title") ?: "MISSION ALERT!"
        val description = intent.getStringExtra("description") ?: ""
        val priority = try { Priority.valueOf(intent.getStringExtra("priority") ?: "NORMAL") } catch (e: Exception) { Priority.NORMAL }

        setContent {
            HeroReminderTheme {
                AlertScreen(
                    reminderId = reminderId,
                    title = title,
                    description = description,
                    priority = priority,
                    onSnooze = { finish() },
                    onComplete = { finish() },
                    onDismiss = { finish() }
                )
            }
        }
    }
}

val heroMessages = listOf(
    "Hey Hero! Your mission awaits! 🦸",
    "Wake up Avenger! The world needs you! ⚡",
    "Time to save the day, Champion! 🛡️",
    "ATTENTION! Priority mission incoming! 🚨",
    "The bat signal is ON! Move it! 🦇",
    "Your superpowers are needed NOW! 💥",
    "Rise and shine, mighty hero! ☀️",
    "Earth's mightiest reminder has arrived! 🌍"
)

@Composable
fun AlertScreen(reminderId: Int, title: String, description: String, priority: Priority, onSnooze: () -> Unit, onComplete: () -> Unit, onDismiss: () -> Unit) {
    var completed by remember { mutableStateOf(false) }
    val heroMessage = remember { heroMessages.random() }

    val infiniteTransition = rememberInfiniteTransition(label = "alert")
    val shake by infiniteTransition.animateFloat(
        -5f, 5f, infiniteRepeatable(tween(100, easing = LinearEasing), RepeatMode.Reverse), label = "shake"
    )
    val pulse by infiniteTransition.animateFloat(
        0.95f, 1.05f, infiniteRepeatable(tween(600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        0.3f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "glow"
    )
    val rotation by infiniteTransition.animateFloat(
        -3f, 3f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "rot"
    )

    val priorityColor = when (priority) {
        Priority.LEGENDARY -> HeroGold
        Priority.HEROIC -> HeroicColor
        Priority.NORMAL -> HeroNeonBlue
    }
    val priorityEmoji = when (priority) {
        Priority.LEGENDARY -> "⚡"; Priority.HEROIC -> "🛡️"; Priority.NORMAL -> "🦸"
    }

    if (completed) {
        CompletedAnimation(onDismiss = onDismiss)
        return
    }

    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.radialGradient(
                listOf(priorityColor.copy(0.2f), HeroDark, Color.Black),
                radius = 900f
            )),
        contentAlignment = Alignment.Center
    ) {
        AnimatedHeroBackground(Modifier.fillMaxSize())

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier.padding(24.dp).fillMaxWidth()
        ) {
            // Top dismiss
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                TextButton(onClick = onDismiss) {
                    Text("✕ Dismiss", color = HeroTextSecondary)
                }
            }

            Spacer(Modifier.height(16.dp))

            // Explosion icon
            Box(
                modifier = Modifier.size(150.dp).graphicsLayer { scaleX = pulse; scaleY = pulse; rotationZ = if (!completed) shake else 0f }
                    .background(
                        Brush.radialGradient(listOf(priorityColor.copy(glowAlpha * 0.4f), Color.Transparent)),
                        RoundedCornerShape(75.dp)
                    )
                    .border(2.dp, priorityColor.copy(glowAlpha), RoundedCornerShape(75.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(priorityEmoji, fontSize = 70.sp, modifier = Modifier.rotate(rotation))
            }

            // Alert label
            Box(
                modifier = Modifier
                    .background(priorityColor.copy(0.15f), RoundedCornerShape(12.dp))
                    .border(1.dp, priorityColor.copy(glowAlpha * 0.7f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text("🚨 ${priority.name} MISSION ALERT", style = MaterialTheme.typography.labelLarge, color = priorityColor)
            }

            // Hero message
            Text(heroMessage, style = MaterialTheme.typography.titleLarge, color = HeroTextPrimary, textAlign = TextAlign.Center)

            // Mission card
            Box(
                modifier = Modifier.fillMaxWidth()
                    .background(HeroGlass, RoundedCornerShape(20.dp))
                    .border(1.dp, priorityColor.copy(glowAlpha * 0.4f), RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MISSION:", style = MaterialTheme.typography.labelLarge, color = HeroTextSecondary)
                    Text(title, style = MaterialTheme.typography.titleLarge, color = HeroTextPrimary)
                    if (description.isNotBlank()) {
                        Text(description, style = MaterialTheme.typography.bodyMedium, color = HeroTextSecondary)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Action Buttons
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // Snooze
                Box(
                    modifier = Modifier.weight(1f).height(56.dp)
                        .background(HeroGlass, RoundedCornerShape(16.dp))
                        .border(1.5.dp, HeroTextSecondary.copy(0.4f), RoundedCornerShape(16.dp))
                        .clickable { onSnooze() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("😴", fontSize = 20.sp)
                        Text("SNOOZE 10m", style = MaterialTheme.typography.labelSmall, color = HeroTextSecondary)
                    }
                }

                // Complete
                Box(
                    modifier = Modifier.weight(1.5f).height(56.dp)
                        .shadow(12.dp, RoundedCornerShape(16.dp), spotColor = priorityColor.copy(0.6f))
                        .background(
                            Brush.linearGradient(listOf(priorityColor.copy(0.9f), priorityColor.copy(0.6f))),
                            RoundedCornerShape(16.dp)
                        )
                        .border(2.dp, priorityColor.copy(glowAlpha), RoundedCornerShape(16.dp))
                        .clickable {
                            completed = true
                            onComplete()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("✅", fontSize = 20.sp)
                        Text("MISSION COMPLETE!", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun CompletedAnimation(onDismiss: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "done")
    val scale by infiniteTransition.animateFloat(0.8f, 1.2f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "s")

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(3000)
        onDismiss()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Brush.radialGradient(listOf(HeroSuccess.copy(0.3f), HeroDark))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("🎉", fontSize = 100.sp, modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale })
            Text("MISSION COMPLETE!", style = MaterialTheme.typography.displayLarge.copy(fontSize = 28.sp), color = HeroSuccess, textAlign = TextAlign.Center)
            Text("You're a true hero! 🦸‍♂️", style = MaterialTheme.typography.titleMedium, color = HeroTextPrimary)
        }
    }
}
