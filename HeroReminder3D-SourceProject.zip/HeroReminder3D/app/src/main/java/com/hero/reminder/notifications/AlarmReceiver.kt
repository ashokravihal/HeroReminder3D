package com.hero.reminder.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Re-schedule all active reminders after boot
            // This would require loading from DB - handled via WorkManager
            return
        }
        val serviceIntent = Intent(context, ReminderService::class.java).apply {
            putExtra("reminder_id", intent.getIntExtra("reminder_id", -1))
            putExtra("title", intent.getStringExtra("title") ?: "Mission Alert!")
            putExtra("description", intent.getStringExtra("description") ?: "")
            putExtra("priority", intent.getStringExtra("priority") ?: "NORMAL")
            putExtra("sound", intent.getStringExtra("sound") ?: "HERO_ALARM")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }
}
