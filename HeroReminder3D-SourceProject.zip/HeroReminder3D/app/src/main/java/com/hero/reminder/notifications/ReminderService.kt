package com.hero.reminder.notifications

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.hero.reminder.R
import com.hero.reminder.ui.screens.AlertActivity

class ReminderService : Service() {
    companion object {
        const val CHANNEL_ID = "hero_reminder_channel"
        const val CHANNEL_HIGH_ID = "hero_reminder_high"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val reminderId = intent?.getIntExtra("reminder_id", -1) ?: -1
        val title = intent?.getStringExtra("title") ?: "Mission Alert!"
        val description = intent?.getStringExtra("description") ?: ""
        val priority = intent?.getStringExtra("priority") ?: "NORMAL"

        // Start foreground with notification
        val notification = buildNotification(reminderId, title, description, priority)
        startForeground(reminderId.takeIf { it != -1 } ?: 1, notification)

        // Launch full-screen alert activity
        val alertIntent = Intent(this, AlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("reminder_id", reminderId)
            putExtra("title", title)
            putExtra("description", description)
            putExtra("priority", priority)
            putExtra("sound", intent?.getStringExtra("sound"))
        }
        startActivity(alertIntent)

        // Vibrate
        vibrate()

        // Play sound
        try {
            val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val ringtone = RingtoneManager.getRingtone(this, ringtoneUri)
            ringtone.play()
        } catch (e: Exception) { e.printStackTrace() }

        stopSelf(startId)
        return START_NOT_STICKY
    }

    private fun vibrate() {
        val pattern = longArrayOf(0, 500, 200, 500, 200, 1000)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(pattern, -1)
            }
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            listOf(
                NotificationChannel(CHANNEL_ID, "Hero Reminders", NotificationManager.IMPORTANCE_DEFAULT),
                NotificationChannel(CHANNEL_HIGH_ID, "Mission Alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                    enableLights(true); enableVibration(true)
                }
            ).forEach { (getSystemService(NotificationManager::class.java)).createNotificationChannel(it) }
        }
    }

    private fun buildNotification(id: Int, title: String, desc: String, priority: String): Notification {
        val tapIntent = PendingIntent.getActivity(
            this, id,
            Intent(this, AlertActivity::class.java).apply {
                putExtra("reminder_id", id); putExtra("title", title); putExtra("priority", priority)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val emoji = when (priority) { "LEGENDARY" -> "⚡"; "HEROIC" -> "🛡️"; else -> "🦸" }
        return NotificationCompat.Builder(this, CHANNEL_HIGH_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("$emoji $title")
            .setContentText(desc.ifEmpty { "Your mission awaits, Hero!" })
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(tapIntent)
            .setAutoCancel(true)
            .build()
    }
}
