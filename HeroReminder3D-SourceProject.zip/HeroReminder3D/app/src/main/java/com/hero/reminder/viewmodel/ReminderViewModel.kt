package com.hero.reminder.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.hero.reminder.data.db.ReminderDatabase
import com.hero.reminder.data.model.*
import com.hero.reminder.data.repository.ReminderRepository
import com.hero.reminder.notifications.AlarmScheduler
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ReminderViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = ReminderRepository(ReminderDatabase.getDatabase(application).reminderDao())
    private val scheduler = AlarmScheduler(application)

    val reminders: StateFlow<List<Reminder>> = repo.getAllReminders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _showAddDialog = MutableStateFlow(false)
    val showAddDialog: StateFlow<Boolean> = _showAddDialog

    private val _editingReminder = MutableStateFlow<Reminder?>(null)
    val editingReminder: StateFlow<Reminder?> = _editingReminder

    fun showAddReminder() { _showAddDialog.value = true; _editingReminder.value = null }
    fun showEditReminder(r: Reminder) { _editingReminder.value = r; _showAddDialog.value = true }
    fun hideDialog() { _showAddDialog.value = false; _editingReminder.value = null }

    fun saveReminder(
        title: String, description: String, dateTimeMillis: Long,
        priority: Priority, repeatType: RepeatType, sound: HeroSound,
        existingId: Int? = null
    ) = viewModelScope.launch {
        val reminder = Reminder(
            id = existingId ?: 0,
            title = title, description = description,
            dateTimeMillis = dateTimeMillis, priority = priority,
            repeatType = repeatType, sound = sound
        )
        val id = if (existingId == null) repo.insert(reminder).toInt()
        else { repo.update(reminder.copy(id = existingId)); existingId }
        scheduler.scheduleAlarm(reminder.copy(id = id))
        hideDialog()
    }

    fun deleteReminder(reminder: Reminder) = viewModelScope.launch {
        scheduler.cancelAlarm(reminder.id)
        repo.delete(reminder)
    }

    fun completeReminder(id: Int) = viewModelScope.launch {
        repo.markCompleted(id)
        scheduler.cancelAlarm(id)
    }

    fun toggleReminder(reminder: Reminder) = viewModelScope.launch {
        val updated = reminder.copy(isActive = !reminder.isActive)
        repo.update(updated)
        if (updated.isActive) scheduler.scheduleAlarm(updated)
        else scheduler.cancelAlarm(updated.id)
    }
}
