package com.hero.reminder.data.db

import androidx.room.*
import com.hero.reminder.data.model.Reminder
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY dateTimeMillis ASC")
    fun getAllReminders(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun getReminderById(id: Int): Reminder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: Reminder): Long

    @Update
    suspend fun updateReminder(reminder: Reminder)

    @Delete
    suspend fun deleteReminder(reminder: Reminder)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteReminderById(id: Int)

    @Query("UPDATE reminders SET isCompleted = :completed WHERE id = :id")
    suspend fun markCompleted(id: Int, completed: Boolean)

    @Query("SELECT * FROM reminders WHERE isActive = 1 AND isCompleted = 0 AND dateTimeMillis > :now ORDER BY dateTimeMillis ASC")
    fun getActiveReminders(now: Long = System.currentTimeMillis()): Flow<List<Reminder>>
}
