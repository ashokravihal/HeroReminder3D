package com.hero.reminder.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.*
import com.hero.reminder.ui.theme.*
import kotlin.math.*

// ─── Animated Particle Background ────────────────────────────────────────────
data class Particle(val x: Float, val y: Float, val radius: Float, val speed: Float, val color: Color, var angle: Float)

@Composable
fun AnimatedHeroBackground(modifier: Modifier = Modifier) {
    val particles = remember {
        List(60) {
            Particle(
                x = (Math.random() * 1000).toFloat(),
                y = (Math.random() * 2000).toFloat(),
                radius = (Math.random() * 3 + 1).toFloat(),
                speed = (Math.random() * 0.5 + 0.2).toFloat(),
                color = listOf(HeroNeonBlue, HeroGold, HeroRedGlow, HeroNeonPurple).random().copy(alpha = (Math.random() * 0.6 + 0.2).toFloat()),
                angle = (Math.random() * 360).toFloat()
            )
        }.toMutableStateList()
    }
    val infiniteTransition = rememberInfiniteTransition(label = "bg")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1000f,
        animationSpec = infiniteRepeatable(tween(100000, easing = LinearEasing)), label = "time"
    )
    Canvas(modifier = modifier) {
        val w = size.width; val h = size.height
        // Dark gradient background
        drawRect(
            brush = Brush.verticalGradient(listOf(HeroDark, HeroDeepBlue, Color(0xFF060E22))),
            size = size
        )
        // Grid lines
        val gridAlpha = 0.05f
        for (i in 0..20) {
            val x = w * i / 20f
            drawLine(HeroNeonBlue.copy(alpha = gridAlpha), Offset(x, 0f), Offset(x, h), 0.5f)
        }
        for (i in 0..40) {
            val y = h * i / 40f
            drawLine(HeroNeonBlue.copy(alpha = gridAlpha), Offset(0f, y), Offset(w, y), 0.5f)
        }
        // Particles
        particles.forEach { p ->
            val px = ((p.x + cos(Math.toRadians(p.angle.toDouble())).toFloat() * time * p.speed) % w + w) % w
            val py = ((p.y + sin(Math.toRadians(p.angle.toDouble())).toFloat() * time * p.speed) % h + h) % h
            drawCircle(color = p.color, radius = p.radius, center = Offset(px, py))
            // Glow around particle
            drawCircle(color = p.color.copy(alpha = p.color.alpha * 0.3f), radius = p.radius * 3, center = Offset(px, py))
        }
        // Nebula orbs
        listOf(
            Triple(w * 0.2f, h * 0.15f, HeroNeonBlue),
            Triple(w * 0.8f, h * 0.4f, HeroGold),
            Triple(w * 0.3f, h * 0.7f, HeroNeonPurple),
            Triple(w * 0.9f, h * 0.85f, HeroRedGlow)
        ).forEach { (x, y, color) ->
            drawCircle(
                brush = Brush.radialGradient(listOf(color.copy(alpha = 0.1f), Color.Transparent), center = Offset(x, y), radius = 300f),
                radius = 300f, center = Offset(x, y)
            )
        }
    }
}

// ─── Glass Card ──────────────────────────────────────────────────────────────
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    glowColor: Color = HeroNeonBlue,
    cornerRadius: Dp = 20.dp,
    elevation: Dp = 8.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .shadow(elevation, RoundedCornerShape(cornerRadius), spotColor = glowColor.copy(alpha = 0.5f))
            .background(
                brush = Brush.linearGradient(listOf(HeroGlassStrong, HeroGlass)),
                shape = RoundedCornerShape(cornerRadius)
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(glowColor.copy(alpha = 0.7f), HeroBorder, glowColor.copy(alpha = 0.3f))),
                shape = RoundedCornerShape(cornerRadius)
            ),
        content = content
    )
}

// ─── Neon Glow Text ───────────────────────────────────────────────────────────
@Composable
fun NeonText(
    text: String,
    style: androidx.compose.ui.text.TextStyle,
    glowColor: Color = HeroNeonBlue,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        // Glow layers
        repeat(3) { i ->
            Text(
                text = text, style = style,
                color = glowColor.copy(alpha = 0.2f - i * 0.05f),
                modifier = Modifier.offset((i + 1).dp, (i + 1).dp)
            )
        }
        Text(text = text, style = style, color = HeroTextPrimary)
    }
}

// ─── Pulse Animation Modifier ─────────────────────────────────────────────────
@Composable
fun Modifier.pulseGlow(color: Color, enabled: Boolean = true): Modifier {
    if (!enabled) return this
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "alpha"
    )
    return this.border(2.dp, color.copy(alpha = alpha), RoundedCornerShape(16.dp))
}

// ─── Hero Badge ───────────────────────────────────────────────────────────────
@Composable
fun PriorityBadge(priority: com.hero.reminder.data.model.Priority) {
    val (label, color, emoji) = when (priority) {
        com.hero.reminder.data.model.Priority.NORMAL -> Triple("NORMAL", NormalColor, "🔵")
        com.hero.reminder.data.model.Priority.HEROIC -> Triple("HEROIC", HeroicColor, "🔥")
        com.hero.reminder.data.model.Priority.LEGENDARY -> Triple("LEGENDARY", LegendaryColor, "⚡")
    }
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text("$emoji $label", style = MaterialTheme.typography.labelSmall, color = color)
    }
}

// ─── Floating Action Button ───────────────────────────────────────────────────
@Composable
fun HeroFAB(onClick: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "fab")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g"
    )
    Box(contentAlignment = Alignment.Center) {
        // Glow ring
        Box(
            modifier = Modifier
                .size(80.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .background(
                    brush = Brush.radialGradient(listOf(HeroNeonBlue.copy(alpha = glowAlpha * 0.3f), Color.Transparent)),
                    shape = RoundedCornerShape(40.dp)
                )
        )
        FloatingActionButton(
            onClick = onClick,
            containerColor = Color.Transparent,
            modifier = Modifier
                .size(64.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .background(
                    brush = Brush.linearGradient(listOf(HeroNeonBlue, HeroNeonPurple)),
                    shape = RoundedCornerShape(32.dp)
                )
                .border(2.dp, HeroNeonBlue.copy(alpha = glowAlpha), RoundedCornerShape(32.dp))
        ) {
            Text("⚡", fontSize = 28.sp)
        }
    }
}
