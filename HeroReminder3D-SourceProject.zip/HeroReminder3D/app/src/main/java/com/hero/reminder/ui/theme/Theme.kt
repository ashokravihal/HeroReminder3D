package com.hero.reminder.ui.theme

import androidx.compose.material3.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// === HERO COLOR PALETTE ===
val HeroDark = Color(0xFF050A18)
val HeroDeepBlue = Color(0xFF0A1628)
val HeroMidBlue = Color(0xFF0D2040)
val HeroNavy = Color(0xFF112255)
val HeroRed = Color(0xFFE53935)
val HeroRedGlow = Color(0xFFFF5252)
val HeroGold = Color(0xFFFFD700)
val HeroGoldGlow = Color(0xFFFFE040)
val HeroNeonBlue = Color(0xFF00E5FF)
val HeroNeonPurple = Color(0xFF7C4DFF)
val HeroGlass = Color(0x1AFFFFFF)
val HeroGlassStrong = Color(0x33FFFFFF)
val HeroBorder = Color(0x4DFFFFFF)
val HeroTextPrimary = Color(0xFFF0F4FF)
val HeroTextSecondary = Color(0xFFB0BEC5)
val HeroSuccess = Color(0xFF00E676)

// Priority Colors
val NormalColor = Color(0xFF4FC3F7)
val HeroicColor = Color(0xFFFF9800)
val LegendaryColor = Color(0xFFFFD700)

val DarkColorScheme = darkColorScheme(
    primary = HeroNeonBlue,
    onPrimary = HeroDark,
    primaryContainer = HeroNavy,
    secondary = HeroGold,
    onSecondary = HeroDark,
    background = HeroDark,
    surface = HeroDeepBlue,
    onBackground = HeroTextPrimary,
    onSurface = HeroTextPrimary,
    error = HeroRed
)

val HeroTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Black, fontSize = 36.sp, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 22.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, letterSpacing = 0.15.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 14.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.5.sp)
)
