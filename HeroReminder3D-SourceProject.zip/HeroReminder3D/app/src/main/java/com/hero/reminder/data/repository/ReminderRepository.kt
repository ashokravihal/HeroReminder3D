package com.hero.reminder.data.repository

import com.hero.reminder.data.db.ReminderDao
import com.hero.reminder.data.model.Reminder
import kotlinx.coroutines.flow.Flow

class ReminderRepository(private val dao: ReminderDao) {
    fun getAllReminders(): Flow<List<Reminder>> = dao.getAllReminders()
    fun getActiveReminders(): Flow<List<Reminder>> = dao.getActiveReminders()
    suspend fun insert(reminder: Reminder): Long = dao.insertReminder(reminder)
    suspend fun update(reminder: Reminder) = dao.updateReminder(reminder)
    suspend fun delete(reminder: Reminder) = dao.deleteReminder(reminder)
    suspend fun deleteById(id: Int) = dao.deleteReminderById(id)
    suspend fun markCompleted(id: Int) = dao.markCompleted(id, true)
    suspend fun getById(id: Int): Reminder? = dao.getReminderById(id)
}
