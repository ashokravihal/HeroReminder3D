package com.hero.reminder.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.hero.reminder.data.model.*
import com.hero.reminder.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

@Composable
fun ReminderCard(
    reminder: Reminder,
    onDelete: () -> Unit,
    onComplete: () -> Unit,
    onEdit: () -> Unit,
    onToggle: () -> Unit
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var isDismissing by remember { mutableStateOf(false) }
    var tiltX by remember { mutableFloatStateOf(0f) }

    val animatedOffset by animateFloatAsState(
        if (isDismissing) -1200f else offsetX,
        animationSpec = if (isDismissing) tween(300) else spring(stiffness = Spring.StiffnessHigh),
        finishedListener = { if (isDismissing) onDelete() },
        label = "offset"
    )
    val cardAlpha by animateFloatAsState(
        if (abs(offsetX) > 200 || isDismissing) 0f else 1f,
        label = "alpha"
    )
    val glowColor = when (reminder.priority) {
        Priority.LEGENDARY -> HeroGold
        Priority.HEROIC -> HeroicColor
        Priority.NORMAL -> HeroNeonBlue
    }
    val infiniteTransition = rememberInfiniteTransition(label = "card")
    val borderGlow by infiniteTransition.animateFloat(
        0.3f, 0.8f,
        infiniteRepeatable(tween(2000 + reminder.id * 300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "border"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .graphicsLayer { translationX = animatedOffset; this.alpha = cardAlpha }
    ) {
        if (offsetX < -50) {
            Box(
                modifier = Modifier.fillMaxSize()
                    .background(HeroRed.copy(alpha = 0.8f), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text("💥 DELETE", color = Color.White,
                    modifier = Modifier.padding(end = 24.dp),
                    style = MaterialTheme.typography.labelLarge)
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (offsetX < -200) {
                                isDismissing = true
                            } else {
                                offsetX = 0f
                                tiltX = 0f
                            }
                        }
                    ) { _, dragAmount ->
                        if (dragAmount < 0) {
                            offsetX = (offsetX + dragAmount).coerceIn(-400f, 0f)
                            tiltX = (offsetX / 400f) * -10f
                        }
                    }
                }
                .graphicsLayer { rotationY = tiltX; cameraDistance = 12f * density }
                .shadow(12.dp, RoundedCornerShape(20.dp), spotColor = glowColor.copy(alpha = 0.4f))
                .background(
                    Brush.linearGradient(listOf(
                        HeroDeepBlue.copy(alpha = 0.95f),
                        HeroMidBlue.copy(alpha = 0.9f),
                        HeroDeepBlue.copy(alpha = 0.95f)
                    )), RoundedCornerShape(20.dp)
                )
                .border(
                    1.5.dp,
                    Brush.linearGradient(listOf(
                        glowColor.copy(alpha = borderGlow),
                        HeroBorder,
                        glowColor.copy(alpha = borderGlow * 0.4f)
                    )),
                    RoundedCornerShape(20.dp)
                )
                .clickable { onEdit() }
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp).fillMaxHeight()
                    .background(
                        Brush.verticalGradient(listOf(glowColor, glowColor.copy(alpha = 0.3f))),
                        RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp)
                    )
            )
            Row(
                modifier = Modifier.fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(44.dp)
                        .background(glowColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                        .border(1.dp, glowColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(when (reminder.priority) {
                        Priority.LEGENDARY -> "⚡"
                        Priority.HEROIC -> "🛡️"
                        Priority.NORMAL -> "🦸"
                    }, fontSize = 22.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(reminder.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (reminder.isCompleted) HeroTextSecondary else HeroTextPrimary,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text("📅 ${SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()).format(Date(reminder.dateTimeMillis))}",
                        style = MaterialTheme.typography.bodyMedium, color = HeroTextSecondary)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PriorityBadge(reminder.priority)
                        if (reminder.repeatType != RepeatType.NONE) {
                            Box(modifier = Modifier
                                .background(HeroNeonPurple.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                .border(1.dp, HeroNeonPurple.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) { Text("🔄 ${reminder.repeatType.name}", style = MaterialTheme.typography.labelSmall, color = HeroNeonPurple) }
                        }
                        if (reminder.isCompleted) {
                            Box(modifier = Modifier
                                .background(HeroSuccess.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) { Text("✅ DONE", style = MaterialTheme.typography.labelSmall, color = HeroSuccess) }
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (!reminder.isCompleted) {
                        IconButton(onClick = onComplete,
                            modifier = Modifier.size(36.dp).background(HeroSuccess.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                        ) { Text("✅", fontSize = 16.sp) }
                    }
                    IconButton(onClick = onToggle,
                        modifier = Modifier.size(36.dp)
                            .background((if (reminder.isActive) HeroNeonBlue else HeroTextSecondary).copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                    ) {
                        Icon(if (reminder.isActive) Icons.Default.Notifications else Icons.Default.NotificationsOff,
                            null, tint = if (reminder.isActive) HeroNeonBlue else HeroTextSecondary,
                            modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
