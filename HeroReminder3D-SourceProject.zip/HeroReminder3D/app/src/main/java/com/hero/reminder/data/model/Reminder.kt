package com.hero.reminder.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Priority { NORMAL, HEROIC, LEGENDARY }
enum class RepeatType { NONE, DAILY, WEEKLY, MONTHLY }
enum class HeroSound { HERO_ALARM, FUNNY_VOICE, DRAMATIC_MISSION }

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String = "",
    val dateTimeMillis: Long,
    val priority: Priority = Priority.NORMAL,
    val repeatType: RepeatType = RepeatType.NONE,
    val sound: HeroSound = HeroSound.HERO_ALARM,
    val isCompleted: Boolean = false,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
