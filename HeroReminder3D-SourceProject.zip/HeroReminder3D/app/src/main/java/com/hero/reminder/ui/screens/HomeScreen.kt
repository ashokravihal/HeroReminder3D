package com.hero.reminder.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hero.reminder.data.model.Reminder
import com.hero.reminder.ui.components.*
import com.hero.reminder.ui.theme.*
import com.hero.reminder.viewmodel.ReminderViewModel

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun HomeScreen(viewModel: ReminderViewModel) {
    val reminders by viewModel.reminders.collectAsState()
    val showDialog by viewModel.showAddDialog.collectAsState()
    val editingReminder by viewModel.editingReminder.collectAsState()

    // Permission launcher
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Box(Modifier.fillMaxSize()) {
        // Animated background
        AnimatedHeroBackground(Modifier.fillMaxSize())

        Column(Modifier.fillMaxSize()) {
            // Top Bar
            HeroTopBar(reminderCount = reminders.count { !it.isCompleted && it.isActive })

            // Stats Row
            StatsRow(reminders)

            // Mission List
            if (reminders.isEmpty()) {
                EmptyState(modifier = Modifier.weight(1f))
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 100.dp, top = 8.dp)
                ) {
                    val active = reminders.filter { !it.isCompleted }
                    val completed = reminders.filter { it.isCompleted }

                    if (active.isNotEmpty()) {
                        item {
                            SectionHeader("⚡ ACTIVE MISSIONS (${active.size})", HeroNeonBlue)
                        }
                        items(active, key = { it.id }) { reminder ->
                            AnimatedVisibility(
                                visible = true,
                                enter = slideInHorizontally(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()
                            ) {
                                ReminderCard(
                                    reminder = reminder,
                                    onDelete = { viewModel.deleteReminder(reminder) },
                                    onComplete = { viewModel.completeReminder(reminder.id) },
                                    onEdit = { viewModel.showEditReminder(reminder) },
                                    onToggle = { viewModel.toggleReminder(reminder) }
                                )
                            }
                        }
                    }
                    if (completed.isNotEmpty()) {
                        item {
                            SectionHeader("✅ COMPLETED MISSIONS (${completed.size})", HeroSuccess)
                        }
                        items(completed, key = { it.id }) { reminder ->
                            ReminderCard(
                                reminder = reminder,
                                onDelete = { viewModel.deleteReminder(reminder) },
                                onComplete = { },
                                onEdit = { },
                                onToggle = { }
                            )
                        }
                    }
                }
            }
        }

        // FAB
        Box(
            modifier = Modifier.fillMaxSize().padding(bottom = 32.dp, end = 24.dp),
            contentAlignment = Alignment.BottomEnd
        ) {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Add Mission extended button
                Box(
                    modifier = Modifier.height(52.dp)
                        .shadow(16.dp, RoundedCornerShape(26.dp), spotColor = HeroNeonBlue.copy(0.5f))
                        .background(
                            Brush.linearGradient(listOf(HeroNeonBlue, HeroNeonPurple)),
                            RoundedCornerShape(26.dp)
                        )
                        .border(1.5.dp, HeroNeonBlue.copy(0.7f), RoundedCornerShape(26.dp))
                        .clickable { viewModel.showAddReminder() }
                        .padding(horizontal = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("⚡", fontSize = 18.sp)
                        Text("ADD MISSION", style = MaterialTheme.typography.labelLarge, color = Color.White)
                    }
                }
            }
        }

        // Dialog
        AnimatedVisibility(
            visible = showDialog,
            enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
            exit = scaleOut() + fadeOut()
        ) {
            AddReminderDialog(
                existingReminder = editingReminder,
                onDismiss = viewModel::hideDialog,
                onSave = { title, desc, dt, prio, repeat, sound, id ->
                    viewModel.saveReminder(title, desc, dt, prio, repeat, sound, id)
                }
            )
        }
    }
}

@Composable
fun HeroTopBar(reminderCount: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "tb")
    val titleGlow by infiniteTransition.animateFloat(0.5f, 1f, infiniteRepeatable(tween(2000), RepeatMode.Reverse), label = "tg")

    Box(
        modifier = Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0x99050A18), Color.Transparent)))
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("⚡ HERO REMINDER", style = MaterialTheme.typography.labelLarge,
                    color = HeroNeonBlue.copy(alpha = titleGlow))
                Text("3D MISSION CONTROL", style = MaterialTheme.typography.displayLarge.copy(fontSize = 28.sp),
                    color = HeroTextPrimary)
            }
            Box(
                modifier = Modifier.size(48.dp)
                    .background(HeroNeonBlue.copy(0.1f), RoundedCornerShape(14.dp))
                    .border(1.dp, HeroNeonBlue.copy(0.3f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$reminderCount", style = MaterialTheme.typography.titleLarge, color = HeroNeonBlue)
                    Text("Active", style = MaterialTheme.typography.labelSmall, color = HeroTextSecondary, fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
fun StatsRow(reminders: List<Reminder>) {
    val active = reminders.count { !it.isCompleted && it.isActive }
    val legendary = reminders.count { it.priority.name == "LEGENDARY" && !it.isCompleted }
    val completed = reminders.count { it.isCompleted }

    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatChip("⚡ $active Active", HeroNeonBlue, Modifier.weight(1f))
        StatChip("⭐ $legendary Legendary", HeroGold, Modifier.weight(1f))
        StatChip("✅ $completed Done", HeroSuccess, Modifier.weight(1f))
    }
}

@Composable
fun StatChip(text: String, color: Color, modifier: Modifier) {
    Box(
        modifier = modifier.height(32.dp)
            .background(color.copy(0.1f), RoundedCornerShape(8.dp))
            .border(1.dp, color.copy(0.3f), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = color, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionHeader(title: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(3.dp).height(18.dp).background(color, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(10.dp))
        Text(title, style = MaterialTheme.typography.labelLarge, color = color)
    }
}

@Composable
fun EmptyState(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "empty")
    val float by infiniteTransition.animateFloat(-8f, 8f, infiniteRepeatable(tween(2000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f")

    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("🦸", fontSize = 80.sp, modifier = Modifier.offset(y = float.dp))
            Text("NO MISSIONS YET", style = MaterialTheme.typography.titleLarge, color = HeroTextPrimary)
            Text("The world needs you, Hero!\nTap ⚡ ADD MISSION to begin.", style = MaterialTheme.typography.bodyMedium,
                color = HeroTextSecondary, textAlign = TextAlign.Center)
        }
    }
}
