package com.hero.reminder.ui.components

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.*
import com.hero.reminder.data.model.*
import com.hero.reminder.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AddReminderDialog(
    existingReminder: Reminder? = null,
    onDismiss: () -> Unit,
    onSave: (String, String, Long, Priority, RepeatType, HeroSound, Int?) -> Unit
) {
    var title by remember { mutableStateOf(existingReminder?.title ?: "") }
    var description by remember { mutableStateOf(existingReminder?.description ?: "") }
    var selectedDateTime by remember { mutableLongStateOf(existingReminder?.dateTimeMillis ?: System.currentTimeMillis() + 3600000) }
    var priority by remember { mutableStateOf(existingReminder?.priority ?: Priority.NORMAL) }
    var repeatType by remember { mutableStateOf(existingReminder?.repeatType ?: RepeatType.NONE) }
    var sound by remember { mutableStateOf(existingReminder?.sound ?: HeroSound.HERO_ALARM) }
    val context = LocalContext.current

    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.7f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.fillMaxWidth(0.95f).fillMaxHeight(0.88f).clickable(enabled = false, onClick = {})
        ) {
            Box(modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF0D2040), Color(0xFF060E22), Color(0xFF0A1020))), RoundedCornerShape(28.dp))
                .border(1.5.dp, Brush.linearGradient(listOf(HeroNeonBlue.copy(0.8f), HeroNeonPurple.copy(0.4f), HeroGold.copy(0.3f))), RoundedCornerShape(28.dp))
            )
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(if (existingReminder == null) "⚡ NEW MISSION" else "✏️ EDIT MISSION",
                            style = MaterialTheme.typography.titleLarge, color = HeroNeonBlue)
                        Text("Configure your hero mission", style = MaterialTheme.typography.bodyMedium, color = HeroTextSecondary)
                    }
                    IconButton(onClick = onDismiss,
                        modifier = Modifier.background(HeroGlass, RoundedCornerShape(12.dp))) {
                        Icon(Icons.Default.Close, null, tint = HeroTextSecondary)
                    }
                }
                Divider(color = HeroBorder)

                HeroTextField(value = title, onValueChange = { title = it }, label = "Mission Name", placeholder = "Enter your mission...", emoji = "🦸")
                HeroTextField(value = description, onValueChange = { description = it }, label = "Mission Brief", placeholder = "Optional details...", emoji = "📋", singleLine = false)

                Text("⏰ MISSION TIME", style = MaterialTheme.typography.labelLarge, color = HeroNeonBlue)
                val cal = Calendar.getInstance().also { it.timeInMillis = selectedDateTime }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    HeroSelectorButton(
                        text = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(selectedDateTime)),
                        emoji = "📅", modifier = Modifier.weight(1f)
                    ) {
                        DatePickerDialog(context, { _, y, m, d ->
                            cal.set(y, m, d); selectedDateTime = cal.timeInMillis
                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                    }
                    HeroSelectorButton(
                        text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(selectedDateTime)),
                        emoji = "🕐", modifier = Modifier.weight(1f)
                    ) {
                        TimePickerDialog(context, { _, h, min ->
                            cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, min)
                            selectedDateTime = cal.timeInMillis
                        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
                    }
                }

                Text("🏆 PRIORITY LEVEL", style = MaterialTheme.typography.labelLarge, color = HeroNeonBlue)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Priority.values().forEach { p ->
                        val (color, emoji) = when (p) {
                            Priority.NORMAL -> NormalColor to "🔵"
                            Priority.HEROIC -> HeroicColor to "🔥"
                            Priority.LEGENDARY -> LegendaryColor to "⚡"
                        }
                        val selected = priority == p
                        Box(
                            modifier = Modifier.weight(1f).height(56.dp)
                                .background(if (selected) color.copy(alpha = 0.25f) else HeroGlass, RoundedCornerShape(14.dp))
                                .border(1.5.dp, if (selected) color else HeroBorder, RoundedCornerShape(14.dp))
                                .clickable { priority = p },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(emoji, fontSize = 18.sp)
                                Text(p.name, style = MaterialTheme.typography.labelSmall, color = if (selected) color else HeroTextSecondary)
                            }
                        }
                    }
                }

                Text("🔄 REPEAT", style = MaterialTheme.typography.labelLarge, color = HeroNeonBlue)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RepeatType.values().forEach { r ->
                        val selected = repeatType == r
                        FilterChip(
                            selected = selected, onClick = { repeatType = r },
                            label = { Text(r.name, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = HeroNeonBlue.copy(alpha = 0.2f),
                                selectedLabelColor = HeroNeonBlue
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true, selected = selected,
                                borderColor = HeroBorder, selectedBorderColor = HeroNeonBlue
                            )
                        )
                    }
                }

                Text("🔊 ALARM SOUND", style = MaterialTheme.typography.labelLarge, color = HeroNeonBlue)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    HeroSound.values().forEach { s ->
                        val (emoji, label) = when (s) {
                            HeroSound.HERO_ALARM -> "🚨" to "Hero Alarm"
                            HeroSound.FUNNY_VOICE -> "😂" to "Funny Hero Voice"
                            HeroSound.DRAMATIC_MISSION -> "🎵" to "Dramatic Mission Theme"
                        }
                        val selected = sound == s
                        Row(
                            modifier = Modifier.fillMaxWidth().height(44.dp)
                                .background(if (selected) HeroGold.copy(alpha = 0.12f) else HeroGlass, RoundedCornerShape(12.dp))
                                .border(1.dp, if (selected) HeroGold.copy(alpha = 0.5f) else HeroBorder, RoundedCornerShape(12.dp))
                                .clickable { sound = s }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(emoji, fontSize = 20.sp)
                            Spacer(Modifier.width(12.dp))
                            Text(label, style = MaterialTheme.typography.bodyMedium,
                                color = if (selected) HeroGold else HeroTextPrimary, modifier = Modifier.weight(1f))
                            if (selected) Text("✓", color = HeroGold, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                val isValid = title.isNotBlank() && selectedDateTime > System.currentTimeMillis()
                val infiniteTransition = rememberInfiniteTransition(label = "btn")
                val btnGlow by infiniteTransition.animateFloat(0.5f, 1f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "g")

                Box(
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                        .shadow(if (isValid) 16.dp else 0.dp, RoundedCornerShape(16.dp))
                        .background(
                            if (isValid) Brush.linearGradient(listOf(HeroNeonBlue, HeroNeonPurple))
                            else Brush.linearGradient(listOf(HeroGlass, HeroGlass)),
                            RoundedCornerShape(16.dp)
                        )
                        .border(if (isValid) 1.5.dp else 1.dp, if (isValid) HeroNeonBlue.copy(btnGlow) else HeroBorder, RoundedCornerShape(16.dp))
                        .clickable(enabled = isValid) {
                            onSave(title, description, selectedDateTime, priority, repeatType, sound, existingReminder?.id)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (existingReminder == null) "⚡ LAUNCH MISSION" else "💾 UPDATE MISSION",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isValid) Color.White else HeroTextSecondary
                    )
                }
                if (!isValid && title.isNotBlank()) {
                    Text("⚠️ Please select a future date & time",
                        style = MaterialTheme.typography.bodyMedium, color = HeroRed.copy(alpha = 0.8f))
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun HeroTextField(value: String, onValueChange: (String) -> Unit, label: String, placeholder: String, emoji: String, singleLine: Boolean = true) {
    Column {
        Text("$emoji $label", style = MaterialTheme.typography.labelLarge, color = HeroNeonBlue)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value, onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = HeroTextSecondary.copy(alpha = 0.5f)) },
            singleLine = singleLine,
            modifier = Modifier.fillMaxWidth().then(if (!singleLine) Modifier.height(80.dp) else Modifier),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = HeroNeonBlue, unfocusedBorderColor = HeroBorder,
                focusedContainerColor = HeroGlass, unfocusedContainerColor = HeroGlass,
                focusedTextColor = HeroTextPrimary, unfocusedTextColor = HeroTextPrimary
            ),
            shape = RoundedCornerShape(14.dp)
        )
    }
}

@Composable
fun HeroSelectorButton(text: String, emoji: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier.height(48.dp)
            .background(HeroGlass, RoundedCornerShape(12.dp))
            .border(1.dp, HeroBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("$emoji $text", style = MaterialTheme.typography.bodyMedium, color = HeroTextPrimary)
    }
}
